import { Bot, Workflow, Brain, Zap, Database, LineChart } from 'lucide-react';

const services = [
  {
    icon: Bot,
    title: 'AI Chatbots',
    description: 'Intelligent conversational agents that handle customer queries 24/7 with human-like interactions.',
    gradient: 'from-purple-600 to-blue-600',
  },
  {
    icon: Workflow,
    title: 'Process Automation',
    description: 'Streamline repetitive tasks and workflows with intelligent automation solutions.',
    gradient: 'from-blue-600 to-cyan-600',
  },
  {
    icon: Brain,
    title: 'Machine Learning',
    description: 'Custom ML models trained on your data to provide predictive insights and intelligence.',
    gradient: 'from-violet-600 to-purple-600',
  },
  {
    icon: Zap,
    title: 'API Integration',
    description: 'Seamlessly connect your tools and platforms with AI-powered integrations.',
    gradient: 'from-purple-600 to-pink-600',
  },
  {
    icon: Database,
    title: 'Data Analytics',
    description: 'Transform raw data into actionable insights with advanced AI analytics.',
    gradient: 'from-cyan-600 to-blue-600',
  },
  {
    icon: LineChart,
    title: 'Performance Optimization',
    description: 'Continuously improve operations with AI-driven optimization strategies.',
    gradient: 'from-blue-600 to-violet-600',
  },
];

export default function Services() {
  return (
    <section id="services" className="relative py-32 px-6 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-950/10 to-black"></div>

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-purple-950/50 border border-purple-500/30 rounded-full mb-6">
            <span className="text-sm text-purple-300">Our Services</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="text-gradient">AI-Powered Solutions</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Comprehensive automation services designed to revolutionize your business operations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group relative bg-gradient-to-br from-purple-950/30 to-black border border-purple-500/20 rounded-2xl p-8 hover:border-purple-500/50 transition-all duration-500 hover:transform hover:scale-105 card-glow"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-blue-600/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              <div className="relative z-10">
                <div className={`inline-flex p-4 bg-gradient-to-br ${service.gradient} rounded-xl mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-gradient transition-all duration-300">
                  {service.title}
                </h3>

                <p className="text-gray-400 leading-relaxed">
                  {service.description}
                </p>

                <div className="mt-6 flex items-center text-purple-400 group-hover:text-purple-300 transition-colors">
                  <span className="text-sm font-semibold">Learn More</span>
                  <span className="ml-2 group-hover:ml-4 transition-all duration-300">→</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
